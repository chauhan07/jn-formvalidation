/*************************************/
/*************************************/
/*************************************/
/*************************************/
/************** JN FORM **************/
/**************VALIDATION*************/
/*************************************/
/*************************************/
/*************************************/
/*************************************/

/*
 *   Version: 1.0.0                                                                 
 *   Author: Aditya Chauhan                                                         
 *   License: MIT                                                                   
 *   Description: This script provides the validation logic for form fields such    
 *   as email, password, text, and other input types. It highlights invalid         
 *   fields and displays error messages accordingly.                                
*/

console.log(
    "%cWebsite Built by Aditya Chauhan",
    "background: #0a383f; color: #ffffff; display: block;padding:5px 15px;border-radius:7px"
);